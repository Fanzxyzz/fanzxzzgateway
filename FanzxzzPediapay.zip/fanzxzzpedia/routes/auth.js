const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const db = require('../db');

router.get('/login', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.render('login', { error: null });
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.findUserByUsername(username);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.render('login', { error: 'Username atau password salah' });
  }
  req.session.userId = user.id;
  res.redirect('/dashboard');
});

router.get('/register', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.render('register', { error: null });
});

router.post('/register', (req, res) => {
  const { username, password, confirm } = req.body;
  if (!username || !password) {
    return res.render('register', { error: 'Semua field wajib diisi' });
  }
  if (password !== confirm) {
    return res.render('register', { error: 'Password tidak cocok' });
  }
  if (db.findUserByUsername(username)) {
    return res.render('register', { error: 'Username sudah dipakai' });
  }
  try {
    const user = db.createUser(username, password);
    req.session.userId = user.id;
    res.redirect('/dashboard');
  } catch (e) {
    res.render('register', { error: 'Gagal mendaftar' });
  }
});

router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

module.exports = router;
