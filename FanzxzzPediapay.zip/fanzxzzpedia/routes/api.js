const express = require('express');
const router = express.Router();
const db = require('../db');
const ramashop = require('../utils/ramashop');
const telegram = require('../utils/telegram');

function apiAuth(req, res, next) {
  const key = req.headers['x-api-key'] || req.query.apikey;
  if (!key) {
    return res.status(401).json({ success: false, message: 'X-API-Key required' });
  }
  const user = db.findUserByApikey(key);
  if (!user) {
    return res.status(401).json({ success: false, message: 'Invalid API Key' });
  }
  req.apiUser = user;
  next();
}

// Cek saldo user
router.get('/balance', apiAuth, (req, res) => {
  res.json({
    success: true,
    data: {
      balance: req.apiUser.balance,
      username: req.apiUser.username
    }
  });
});

// Buat deposit QRIS (menggunakan balance sistem / RamaShop)
router.post('/deposit/create', apiAuth, async (req, res) => {
  const amount = parseInt(req.body.amount);
  if (!amount || amount < 100) {
    return res.status(400).json({ success: false, message: 'Minimal amount 100' });
  }

  const result = await ramashop.createDeposit(amount);
  if (!result.success) {
    return res.status(400).json({ success: false, message: result.message || 'Gagal create deposit' });
  }

  const d = result.data;
  db.createDeposit(req.apiUser.id, d.depositId, d.amount, d.totalAmount, d.qrImage, d.qrString);

  res.json({
    success: true,
    data: {
      depositId: d.depositId,
      amount: d.amount,
      totalAmount: d.totalAmount,
      qrImage: d.qrImage,
      qrString: d.qrString,
      status: 'pending',
      expiredAt: d.expiredAt
    }
  });
});

// Cek status deposit
router.get('/deposit/status/:depositId', apiAuth, async (req, res) => {
  const deposit = db.getDeposit(req.params.depositId);
  if (!deposit || deposit.user_id !== req.apiUser.id) {
    return res.status(404).json({ success: false, message: 'Deposit not found' });
  }

  if (deposit.status === 'success') {
    return res.json({
      success: true,
      data: { status: 'success', depositId: deposit.deposit_id, amount: deposit.amount }
    });
  }

  const check = await ramashop.checkDepositStatus(req.params.depositId);
  if (check.data && check.data.status === 'success') {
    db.updateDepositStatus(req.params.depositId, 'success');
    const updated = db.updateBalance(deposit.user_id, deposit.amount);
    await telegram.notifyDepositSuccess({
      nominal: 'Rp ' + Number(deposit.amount).toLocaleString('id-ID'),
      invoiceId: deposit.deposit_id,
      username: updated.username,
      saldoSekarang: 'Rp ' + Number(updated.balance).toLocaleString('id-ID')
    });
    return res.json({
      success: true,
      data: { status: 'success', depositId: deposit.deposit_id, amount: deposit.amount }
    });
  }

  res.json({
    success: true,
    data: {
      status: check.data?.status || 'pending',
      depositId: deposit.deposit_id,
      amount: deposit.amount
    }
  });
});

module.exports = router;
