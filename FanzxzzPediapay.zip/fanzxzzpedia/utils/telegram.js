const TelegramBot = require('node-telegram-bot-api');
const db = require('../db');

let bot = null;
const OWNER_ID = process.env.OWNER_ID;
const CHANNEL = process.env.CHANNEL_USERNAME;
const WEBSITE_URL = process.env.WEBSITE_URL || 'http://localhost:3000';

function initBot(token) {
  if (!token) {
    console.warn('[Telegram] BOT_TOKEN tidak ditemukan, bot tidak diaktifkan.');
    return null;
  }
  bot = new TelegramBot(token, { polling: true });
  setupHandlers();
  console.log('[Telegram] Bot aktif & polling...');
  return bot;
}

function getBot() {
  return bot;
}

function formatWIB(date = new Date()) {
  return date.toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  }) + ' WIB';
}

function setupHandlers() {
  bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const user = db.findUserByTelegramId(chatId);
    const saldo = user ? user.balance : 0;

    const text = `<blockquote>Halo, Selamat Datang Di Bot Layanan Payment Gateway FanzxzzPedia</blockquote>
─────────────────
🌟 FanzxzzPedia - Adalah Layanan Payment Gateway Untuk Terima Pembayaran Qris Otomatis bagi bot & Aplikasi Platform Anda..
Saldo Anda : Rp ${Number(saldo).toLocaleString('id-ID')}
─────────────────
🧩 Sila Lanjut Melalui Tombol Dibawah`;

    const keyboard = {
      inline_keyboard: [
        [{ text: 'Hubungkan Apikey', callback_data: 'link_apikey' }],
        [{ text: 'Deposit', callback_data: 'bot_deposit' }],
        [{ text: 'Kunjungi Website', url: WEBSITE_URL }],
        [{ text: 'Whitdraw', callback_data: 'bot_withdraw' }]
      ]
    };

    bot.sendMessage(chatId, text, { parse_mode: 'HTML', reply_markup: keyboard });
  });

  bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    const data = query.data;
    const user = db.findUserByTelegramId(chatId);

    if (data === 'link_apikey') {
      bot.sendMessage(chatId, 'Kirim API Key kamu (dari website FanzxzzPedia) dengan format:\n\n<code>/link APIKEYKAMU</code>', { parse_mode: 'HTML' });
    }

    if (data === 'bot_deposit') {
      if (!user) {
        return bot.sendMessage(chatId, 'Kamu belum menghubungkan API Key. Gunakan tombol Hubungkan Apikey terlebih dahulu.');
      }
      bot.sendMessage(chatId, 'Untuk deposit, silakan buka website dan menu Deposit.\nAtau kirim nominal deposit (contoh: 10000)');
    }

    if (data === 'bot_withdraw') {
      if (!user) {
        return bot.sendMessage(chatId, 'Kamu belum menghubungkan API Key.');
      }
      if (user.balance <= 0) {
        return bot.sendMessage(chatId, 'Saldo kamu 0. Tidak bisa withdraw.');
      }
      bot.sendMessage(chatId, `Saldo kamu: Rp ${Number(user.balance).toLocaleString('id-ID')}\n\nKirim format withdraw:\n<code>/wd NOMOR EWALLET JENIS</code>\n\nContoh:\n<code>/wd 085138449569 dana</code>\n\nEwallet tersedia: dana, gopay, ovo`, { parse_mode: 'HTML' });
    }

    // Owner approve / reject
    if (data.startsWith('wd_approve_') || data.startsWith('wd_reject_')) {
      if (String(chatId) !== String(OWNER_ID)) {
        return bot.answerCallbackQuery(query.id, { text: 'Hanya owner!' });
      }
      const wdId = data.split('_').pop();
      const wd = db.getWithdraw(wdId);
      if (!wd || wd.status !== 'pending') {
        return bot.answerCallbackQuery(query.id, { text: 'Sudah diproses / tidak ditemukan' });
      }

      if (data.startsWith('wd_approve_')) {
        db.updateWithdrawStatus(wdId, 'approved');
        // saldo sudah dikurangi saat request, jadi tidak perlu kurangi lagi
        const textUser = `𝗪𝗵𝗶𝘁𝗱𝗿𝗮𝘄 𝗗𝗶𝘀𝗲𝘁𝘂𝗷𝘂𝗶! ✅
───────────────
Nomor Tujuan : ${wd.number}
Tanggal & Waktu : ${formatWIB()}
Saldo Berhasil Wd : Rp ${Number(wd.amount).toLocaleString('id-ID')}
Sisa Saldo : Rp ${Number(db.findUserById(wd.user_id).balance).toLocaleString('id-ID')}
─────
━━
Terima Kasih ─ Sudah Mempercayai FanzxzzPedia 🌟`;
        if (wd.telegram_id) {
          bot.sendMessage(wd.telegram_id, textUser);
        }
        bot.answerCallbackQuery(query.id, { text: 'Disetujui' });
        bot.editMessageText(query.message.text + '\n\n✅ DISETUJUI', {
          chat_id: chatId,
          message_id: query.message.message_id
        });
      } else {
        // reject -> kembalikan saldo
        db.updateBalance(wd.user_id, wd.amount);
        db.updateWithdrawStatus(wdId, 'rejected');
        const sisa = db.findUserById(wd.user_id).balance;
        const textUser = `𝗪𝗵𝗶𝘁𝗱𝗿𝗮𝘄 𝗗𝗶𝘁𝗼𝗹𝗮𝗸! ❌
───────────────
𝗦𝗮𝗹𝗱𝗼 𝗦𝗲𝗸𝗮𝗿𝗮𝗻𝗴 : Rp ${Number(sisa).toLocaleString('id-ID')}
━━━━
──
Penarikan Ditolak Mohon Maaf ─ FanzxzzPedia 🌟`;
        if (wd.telegram_id) {
          bot.sendMessage(wd.telegram_id, textUser);
        }
        bot.answerCallbackQuery(query.id, { text: 'Ditolak' });
        bot.editMessageText(query.message.text + '\n\n❌ DITOLAK', {
          chat_id: chatId,
          message_id: query.message.message_id
        });
      }
    }

    bot.answerCallbackQuery(query.id);
  });

  bot.onText(/\/link (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const apikey = match[1].trim();
    const user = db.findUserByApikey(apikey);
    if (!user) {
      return bot.sendMessage(chatId, 'API Key tidak valid.');
    }
    db.linkTelegram(user.id, chatId);
    bot.sendMessage(chatId, `Berhasil dihubungkan!\nUsername: ${user.username}\nSaldo: Rp ${Number(user.balance).toLocaleString('id-ID')}`);
  });

  bot.onText(/\/wd (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const user = db.findUserByTelegramId(chatId);
    if (!user) {
      return bot.sendMessage(chatId, 'Belum hubungkan API Key. Gunakan /link APIKEY');
    }
    const parts = match[1].trim().split(/\s+/);
    if (parts.length < 2) {
      return bot.sendMessage(chatId, 'Format: /wd NOMOR EWALLET\nContoh: /wd 085138449569 dana');
    }
    const number = parts[0];
    const ewallet = parts[1].toLowerCase();
    if (!['dana', 'gopay', 'ovo'].includes(ewallet)) {
      return bot.sendMessage(chatId, 'Ewallet hanya: dana, gopay, ovo');
    }
    // Minta nominal
    bot.sendMessage(chatId, `Kirim nominal yang ingin ditarik (max Rp ${Number(user.balance).toLocaleString('id-ID')}):\n\nContoh: 50000`);
    bot.once('message', (m) => {
      if (m.chat.id !== chatId) return;
      const amount = parseInt(m.text.replace(/\D/g, ''));
      if (!amount || amount <= 0 || amount > user.balance) {
        return bot.sendMessage(chatId, 'Nominal tidak valid atau melebihi saldo.');
      }
      // Kurangi saldo dulu
      db.updateBalance(user.id, -amount);
      const wdId = db.createWithdraw(user.id, amount, ewallet, number);

      // Notif owner
      const notif = `<blockquote>Notif User Whitdraw!!</blockquote>
─────────────────
methode payment ewallet : ${ewallet.toUpperCase()}
nomor ewallet : ${number}
Username : ${user.username}
Nominal : Rp ${amount.toLocaleString('id-ID')}
Sila Tekan Tombol Dibawah`;

      const keyboard = {
        inline_keyboard: [
          [
            { text: 'Setuju', callback_data: `wd_approve_${wdId}` },
            { text: 'Tidak Setuju', callback_data: `wd_reject_${wdId}` }
          ]
        ]
      };
      bot.sendMessage(OWNER_ID, notif, { parse_mode: 'HTML', reply_markup: keyboard });
      bot.sendMessage(chatId, 'Permintaan withdraw sudah dikirim ke owner. Mohon tunggu persetujuan.');
    });
  });
}

async function notifyDepositSuccess({ nominal, invoiceId, username, saldoSekarang }) {
  if (!bot) return;
  const text = `Pembayaran Berhasil ✅

Nominal : ${nominal}
Ref : ${invoiceId}
User : ${username}
Waktu : ${formatWIB()}
Informasi Saldo User :
• Saldo Sekarang : ${saldoSekarang}`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '🌐 Kunjungi Website', url: WEBSITE_URL }]
    ]
  };

  try {
    await bot.sendMessage(CHANNEL, text, { reply_markup: keyboard });
  } catch (e) {
    console.error('Gagal kirim ke channel:', e.message);
  }
}

module.exports = {
  initBot,
  getBot,
  notifyDepositSuccess,
  formatWIB
};
