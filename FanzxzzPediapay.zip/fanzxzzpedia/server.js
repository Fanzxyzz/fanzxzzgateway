require('dotenv').config();
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');

const db = require('./db');
const telegram = require('./utils/telegram');
const authRoutes = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');
const apiRoutes = require('./routes/api');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 4745;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'fanzxzzpedia_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

// Make user available in all views
app.use((req, res, next) => {
  res.locals.currentUser = req.session.userId ? db.findUserById(req.session.userId) : null;
  next();
});

// Routes
app.use('/', authRoutes);
app.use('/dashboard', dashboardRoutes);
app.use('/api', apiRoutes);

// Landing page
app.get('/', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.render('landing');
});

// Docs publik (tanpa login)
app.get('/docs', (req, res) => {
  res.render('docs-public');
});

// Socket.io Live Chat
io.on('connection', (socket) => {
  // Kirim history chat
  const history = db.getRecentChats(40);
  socket.emit('chat_history', history);

  socket.on('chat_message', (data) => {
    if (!data.message || !data.message.trim()) return;
    const username = data.username || 'Guest';
    const userId = data.userId || null;
    const isOwner = data.isOwner ? 1 : 0;

    db.addChatMessage(userId, username, data.message.trim(), isOwner);
    io.emit('chat_message', {
      username,
      message: data.message.trim(),
      isOwner,
      time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    });
  });
});

// Polling deposit pending setiap 15 detik
setInterval(async () => {
  const pending = db.getPendingDeposits();
  const ramashop = require('./utils/ramashop');
  for (const dep of pending) {
    try {
      const check = await ramashop.checkDepositStatus(dep.deposit_id);
      if (check.data && check.data.status === 'success') {
        db.updateDepositStatus(dep.deposit_id, 'success');
        const updated = db.updateBalance(dep.user_id, dep.amount);
        await telegram.notifyDepositSuccess({
          nominal: 'Rp ' + Number(dep.amount).toLocaleString('id-ID'),
          invoiceId: dep.deposit_id,
          username: updated.username,
          saldoSekarang: 'Rp ' + Number(updated.balance).toLocaleString('id-ID')
        });
        console.log(`[Deposit] Success: ${dep.deposit_id} +${dep.amount}`);
      } else if (check.data && check.data.status === 'expired') {
        db.updateDepositStatus(dep.deposit_id, 'expired');
      }
    } catch (e) {
      // ignore
    }
  }
}, 15000);

// Start Telegram Bot
telegram.initBot(process.env.BOT_TOKEN);

server.listen(PORT, () => {
  console.log(`========================================`);
  console.log(`  FanzxzzPedia Payment Gateway`);
  console.log(`  Running on http://localhost:${PORT}`);
  console.log(`========================================`);
});
